<?php
$string['pluginname'] = 'Feed Forward Plugin';
