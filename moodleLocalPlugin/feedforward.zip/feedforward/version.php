<?php
defined('MOODLE_INTERNAL') || die();

$plugin->component = 'local_feedforward'; // Full name of the plugin
$plugin->version   = 2025091600;              // YYYYMMDDXX
$plugin->requires  = 2022041900;              // Moodle version requirement
