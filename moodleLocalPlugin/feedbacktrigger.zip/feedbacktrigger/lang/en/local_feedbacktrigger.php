<?php
$string['pluginname'] = 'Feedback Trigger';
