<?php
defined('MOODLE_INTERNAL') || die();

$plugin->component = 'local_feedbacktrigger';
$plugin->version   = 2025091600;
$plugin->requires  = 2022041900;
